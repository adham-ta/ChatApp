# Messaging App UI with Dark Mode

A Pen created on CodePen.io. Original URL: [https://codepen.io/adham-ta/pen/vYQVZBR](https://codepen.io/adham-ta/pen/vYQVZBR).

Inspired by Alex Banaga
https://dribbble.com/shots/8275108-Facebook-Messenger-Redesign